/**
 * CampusArchive - Academic Project Repository
 * Main Interactive Vanilla JavaScript Module
 */

// Immediately apply saved theme on script load to prevent dark mode flicker
(function() {
  const savedTheme = localStorage.getItem('campusarchive_theme') || 'light';
  document.documentElement.setAttribute('data-theme', savedTheme);
})();

document.addEventListener('DOMContentLoaded', () => {
  // Initialize state & components
  initThemeToggle();
  initBookmarks();
  initSearch();
  initCategoryFilters();
  initScrollAnimations();
  initProjectModals();
  initSmoothScroll();
});

/* ==========================================================================
   1. Projects Dataset for Dynamic Filtering & Modals
   ========================================================================== */
const PROJECTS_DATA = [
  {
    id: 'proj-1',
    title: 'AI Based Attendance System',
    category: 'Artificial Intelligence',
    description: 'Smart attendance system using facial recognition and machine learning to automate student tracking with 98.4% accuracy.',
    technologies: ['Python', 'Flask', 'OpenCV', 'MySQL'],
    year: '2024',
    department: 'Computer Science & Engineering',
    author: 'Aarav Sharma & Priya Patel',
    facultyGuide: 'Dr. Ramesh Kumar (HOD CS)',
    image: 'images/project1.jpg',
    downloads: 342,
    stars: 48,
    abstract: 'Traditional attendance methods in educational institutions are time-consuming and prone to proxy marking. This project proposes an automated facial recognition attendance management framework integrated with live camera feeds, real-time logging in MySQL, and an analytics dashboard for faculty members.'
  },
  {
    id: 'proj-2',
    title: 'Smart Waste Management',
    category: 'Web Application',
    description: 'IoT-enabled web platform for efficient municipal and campus waste collection, sensor telemetry, and route optimization.',
    technologies: ['IoT', 'Node.js', 'MongoDB', 'Express'],
    year: '2024',
    department: 'Information Technology',
    author: 'Rohan Mehta & Sanya Malhotra',
    facultyGuide: 'Prof. Ananya Sen',
    image: 'images/project2.jpg',
    downloads: 215,
    stars: 39,
    abstract: 'Urban waste management faces challenges in overflow detection and collection efficiency. Using Ultrasonic IoT sensors mounted in smart bins, data is transmitted to an Express/MongoDB backend. Drivers receive optimized collection routes via an interactive web portal.'
  },
  {
    id: 'proj-3',
    title: 'E-Commerce Website',
    category: 'Web Development',
    description: 'Full-stack responsive e-commerce solution with integrated payment gateway, inventory management, and user authentication.',
    technologies: ['HTML', 'CSS', 'JavaScript', 'PHP'],
    year: '2023',
    department: 'Software Engineering',
    author: 'Vikram Joshi',
    facultyGuide: 'Dr. Meera Nair',
    image: 'images/project3.jpg',
    downloads: 512,
    stars: 64,
    abstract: 'A full-featured e-commerce platform designed for small campus entrepreneurs. Includes cart management, order tracking, real-time stock alerts, dynamic rating reviews, and integrated Stripe/Razorpay mock payment workflow.'
  },
  {
    id: 'proj-4',
    title: 'College Event Management',
    category: 'Education',
    description: 'Centralized system to manage college fests, workshop registrations, venue scheduling, and instant QR pass notifications.',
    technologies: ['Java', 'Spring Boot', 'MySQL'],
    year: '2023',
    department: 'Computer Applications',
    author: 'Neha Gupta & Kabira Singh',
    facultyGuide: 'Prof. Rajesh Verma',
    image: 'images/project4.jpg',
    downloads: 189,
    stars: 27,
    abstract: 'Managing campus events requires seamless registration and attendance verification. Built with Spring Boot and MySQL, this platform generates unique QR entry tickets for registered participants and provides organizers with live check-in telemetry.'
  }
];

/* ==========================================================================
   2. Bookmark System
   ========================================================================== */
function getSavedBookmarks() {
  const saved = localStorage.getItem('campusarchive_bookmarks');
  return saved ? JSON.parse(saved) : [];
}

function saveBookmarks(bookmarks) {
  localStorage.setItem('campusarchive_bookmarks', JSON.stringify(bookmarks));
  updateBookmarkBadgeCount();
}

function initBookmarks() {
  const bookmarkBtns = document.querySelectorAll('.bookmark-btn');
  const savedBookmarks = getSavedBookmarks();

  bookmarkBtns.forEach(btn => {
    const projId = btn.getAttribute('data-project-id');
    
    // Set initial state
    if (savedBookmarks.includes(projId)) {
      btn.classList.add('active');
      btn.innerHTML = '<i class="bi bi-bookmark-fill"></i>';
    } else {
      btn.classList.remove('active');
      btn.innerHTML = '<i class="bi bi-bookmark"></i>';
    }

    // Toggle click handler
    btn.addEventListener('click', (e) => {
      e.stopPropagation(); // Prevent opening modal
      let bookmarks = getSavedBookmarks();
      
      if (bookmarks.includes(projId)) {
        bookmarks = bookmarks.filter(id => id !== projId);
        btn.classList.remove('active');
        btn.innerHTML = '<i class="bi bi-bookmark"></i>';
        showToast('Removed from your bookmarked projects');
      } else {
        bookmarks.push(projId);
        btn.classList.add('active');
        btn.innerHTML = '<i class="bi bi-bookmark-fill"></i>';
        showToast('Saved project to your bookmarks!');
      }
      
      saveBookmarks(bookmarks);
    });
  });

  updateBookmarkBadgeCount();
}

function updateBookmarkBadgeCount() {
  const count = getSavedBookmarks().length;
  const badgeEl = document.getElementById('nav-bookmark-count');
  if (badgeEl) {
    badgeEl.textContent = count;
    badgeEl.style.display = count > 0 ? 'inline-block' : 'none';
  }
}

/* ==========================================================================
   3. Live Search & Project Filtering
   ========================================================================== */
function initSearch() {
  const searchInputs = document.querySelectorAll('.search-input');

  searchInputs.forEach(input => {
    input.addEventListener('input', (e) => {
      const query = e.target.value.toLowerCase().trim();
      filterProjectsByQuery(query);
    });
  });
}

function filterProjectsByQuery(query) {
  const projectCards = document.querySelectorAll('.project-card-col');
  let matchCount = 0;

  projectCards.forEach(cardCol => {
    const title = cardCol.getAttribute('data-title') || '';
    const category = cardCol.getAttribute('data-category') || '';
    const tags = cardCol.getAttribute('data-tags') || '';
    const textContent = (title + ' ' + category + ' ' + tags).toLowerCase();

    if (textContent.includes(query)) {
      cardCol.style.display = 'block';
      matchCount++;
    } else {
      cardCol.style.display = 'none';
    }
  });

  // Handle No Results Message
  let noResultsEl = document.getElementById('no-projects-found');
  if (!noResultsEl) {
    const gridContainer = document.getElementById('projects-grid');
    if (gridContainer) {
      noResultsEl = document.createElement('div');
      noResultsEl.id = 'no-projects-found';
      noResultsEl.className = 'col-12 text-center py-5';
      noResultsEl.innerHTML = `
        <div class="p-4 bg-white rounded-4 shadow-sm border mx-auto" style="max-width: 480px;">
          <i class="bi bi-search text-lavender display-4 mb-3 d-block"></i>
          <h5 class="fw-bold mb-2">No Projects Match Your Search</h5>
          <p class="text-muted small mb-3">Try searching for keywords like "Python", "IoT", "Web", or "AI"</p>
          <button class="btn btn-lavender btn-sm rounded-pill px-4" onclick="clearSearchFilter()">Reset Search</button>
        </div>
      `;
      gridContainer.appendChild(noResultsEl);
    }
  }

  if (noResultsEl) {
    noResultsEl.style.display = (matchCount === 0 && query !== '') ? 'block' : 'none';
  }
}

window.clearSearchFilter = function() {
  document.querySelectorAll('.search-input').forEach(i => i.value = '');
  filterProjectsByQuery('');
  
  // Reset category pills
  document.querySelectorAll('.filter-pill').forEach(pill => {
    pill.classList.toggle('active', pill.getAttribute('data-filter') === 'all');
  });
};

/* ==========================================================================
   4. Category Pills & Category Card Interaction
   ========================================================================== */
function initCategoryFilters() {
  const filterPills = document.querySelectorAll('.filter-pill');
  
  filterPills.forEach(pill => {
    pill.addEventListener('click', () => {
      filterPills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');

      const filterValue = pill.getAttribute('data-filter').toLowerCase();
      const projectCards = document.querySelectorAll('.project-card-col');

      projectCards.forEach(card => {
        const category = (card.getAttribute('data-category') || '').toLowerCase();
        if (filterValue === 'all' || category.includes(filterValue)) {
          card.style.display = 'block';
        } else {
          card.style.display = 'none';
        }
      });
    });
  });

  // Category cards click handler
  const categoryCards = document.querySelectorAll('.category-card');
  categoryCards.forEach(card => {
    card.addEventListener('click', () => {
      const catName = card.getAttribute('data-category-name');
      
      // Scroll to featured projects section smoothly
      const targetSec = document.getElementById('featured-projects');
      if (targetSec) {
        targetSec.scrollIntoView({ behavior: 'smooth' });
      }

      // Filter featured projects by this category
      const projectCards = document.querySelectorAll('.project-card-col');
      projectCards.forEach(pCard => {
        const pCat = (pCard.getAttribute('data-category') || '').toLowerCase();
        if (pCat.includes(catName.toLowerCase()) || catName.toLowerCase().includes(pCat)) {
          pCard.style.display = 'block';
        } else {
          pCard.style.display = 'none';
        }
      });

      showToast(`Filtering projects for: ${catName}`);
    });
  });
}

/* ==========================================================================
   5. Interactive Project Details Modal
   ========================================================================== */
function initProjectModals() {
  const viewDetailBtns = document.querySelectorAll('.view-details-btn');
  const modalEl = document.getElementById('projectDetailsModal');
  
  if (!modalEl) return;

  viewDetailBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const projId = btn.getAttribute('data-project-id');
      const project = PROJECTS_DATA.find(p => p.id === projId) || PROJECTS_DATA[0];

      // Populate Modal Content
      document.getElementById('modalProjectTitle').textContent = project.title;
      document.getElementById('modalProjectCategory').textContent = project.category;
      document.getElementById('modalProjectDept').textContent = project.department;
      document.getElementById('modalProjectAuthor').textContent = project.author;
      document.getElementById('modalProjectGuide').textContent = project.facultyGuide;
      document.getElementById('modalProjectYear').textContent = project.year;
      document.getElementById('modalProjectAbstract').textContent = project.abstract;
      document.getElementById('modalProjectImg').src = project.image;

      // Populate Tech Tags
      const tagsContainer = document.getElementById('modalProjectTags');
      tagsContainer.innerHTML = project.technologies.map(t => `<span class="tech-tag">${t}</span>`).join('');

      // Show Bootstrap Modal
      const bsModal = new bootstrap.Modal(modalEl);
      bsModal.show();
    });
  });
}

/* ==========================================================================
   6. Scroll Animations & Smooth Navigation
   ========================================================================== */
function initScrollAnimations() {
  const animatedElements = document.querySelectorAll('.animate-fade-up');

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
      }
    });
  }, { threshold: 0.1 });

  animatedElements.forEach(el => observer.observe(el));
}

function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      const targetId = this.getAttribute('href');
      if (targetId === '#') return;

      const targetEl = document.querySelector(targetId);
      if (targetEl) {
        e.preventDefault();
        targetEl.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });
}

/* ==========================================================================
   7. Theme Toggle System (Dark Mode)
   ========================================================================== */
function initThemeToggle() {
  const themeToggleBtns = document.querySelectorAll('.theme-toggle-btn');
  const savedTheme = localStorage.getItem('campusarchive_theme') || 'light';

  applyTheme(savedTheme);

  themeToggleBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
      const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
      
      applyTheme(newTheme);
      localStorage.setItem('campusarchive_theme', newTheme);
      showToast(newTheme === 'dark' ? 'Dark mode enabled 🌙' : 'Light mode enabled ☀️');
    });
  });
}

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  const themeToggleBtns = document.querySelectorAll('.theme-toggle-btn');
  
  themeToggleBtns.forEach(btn => {
    if (theme === 'dark') {
      btn.innerHTML = '<i class="bi bi-sun-fill text-warning fs-6"></i>';
      btn.setAttribute('title', 'Switch to Light Mode');
    } else {
      btn.innerHTML = '<i class="bi bi-moon-stars text-lavender fs-6"></i>';
      btn.setAttribute('title', 'Switch to Dark Mode');
    }
  });
}

/* ==========================================================================
   8. Helper Toast Notification
   ========================================================================== */
function showToast(message) {
  let toastContainer = document.querySelector('.toast-container-custom');
  if (!toastContainer) {
    toastContainer = document.createElement('div');
    toastContainer.className = 'toast-container-custom';
    document.body.appendChild(toastContainer);
  }

  const toast = document.createElement('div');
  toast.className = 'toast-custom';
  toast.innerHTML = `
    <i class="bi bi-check-circle-fill text-lavender fs-5"></i>
    <span>${message}</span>
  `;

  toastContainer.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(20px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 2800);
}

// Expose showToast globally
window.showToast = showToast;

// Global image load fallback safety
document.addEventListener('error', function(event) {
  if (event.target && event.target.tagName === 'IMG') {
    const img = event.target;
    if (!img.getAttribute('data-error-handled')) {
      img.setAttribute('data-error-handled', 'true');
      if (img.classList.contains('project-img') || img.id === 'modalProjectImg') {
        img.src = 'images/project1.jpg';
      } else if (img.classList.contains('hero-illustration-img')) {
        img.src = 'images/hero.jpg';
      }
    }
  }
}, true);
